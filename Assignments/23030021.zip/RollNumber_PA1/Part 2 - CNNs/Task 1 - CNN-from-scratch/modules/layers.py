import numpy as np

class ConvolutionLayer:
    def __init__(self, in_channels, out_channels, kernel_size, stride=1):
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride

        self.weights = np.random.rand(
            out_channels, in_channels, kernel_size, kernel_size
        ).astype(np.float32)
        self.bias = np.random.rand(out_channels).astype(np.float32)

        self.inputs = None
        self.has_weights = True

    def forward(self, inputs):
        self.inputs = inputs
        batch_size, _, in_height, in_width = inputs.shape
        out_height = (in_height - self.kernel_size) // self.stride + 1
        out_width = (in_width - self.kernel_size) // self.stride + 1

        output = np.zeros((batch_size, self.out_channels, out_height, out_width))

        for b in range(batch_size):
            for c_out in range(self.out_channels):
                for h in range(out_height):
                    for w in range(out_width):
                        h_start = h * self.stride
                        w_start = w * self.stride
                        region = inputs[b, :, h_start:h_start + self.kernel_size, w_start:w_start + self.kernel_size]
                        output[b, c_out, h, w] = np.sum(region * self.weights[c_out]) + self.bias[c_out]
        return output

    def backward(self, d_outputs):
        if self.inputs is None:
            raise NotImplementedError("Need to call forward function before backward function")

        batch_size, _, in_height, in_width = self.inputs.shape
        _, _, out_height, out_width = d_outputs.shape

        d_inputs = np.zeros_like(self.inputs)
        d_weights = np.zeros_like(self.weights)
        d_bias = np.zeros_like(self.bias)

        for b in range(batch_size):
            for c_out in range(self.out_channels):
                for h in range(out_height):
                    for w in range(out_width):
                        h_start = h * self.stride
                        w_start = w * self.stride
                        region = self.inputs[b, :, h_start:h_start + self.kernel_size, w_start:w_start + self.kernel_size]
                        d_weights[c_out] += region * d_outputs[b, c_out, h, w]
                        d_inputs[b, :, h_start:h_start + self.kernel_size, w_start:w_start + self.kernel_size] += self.weights[c_out] * d_outputs[b, c_out, h, w]
                        d_bias[c_out] += d_outputs[b, c_out, h, w]

        return {"d_weights": d_weights, "d_bias": d_bias, "d_out": d_inputs}

    def update(self, d_weights, d_bias, learning_rate):
        self.weights -= learning_rate * d_weights
        self.bias -= learning_rate * d_bias


class Flatten:
    def __init__(self):
        self.inputs_shape = None
        self.has_weights = False

    def forward(self, inputs):
        self.inputs_shape = inputs.shape
        return inputs.reshape(inputs.shape[0], -1)

    def backward(self, d_outputs):
        return {"d_out": d_outputs.reshape(self.inputs_shape)}


class LinearLayer:
    def __init__(self, in_features, out_features):
        self.in_features = in_features
        self.out_features = out_features

        self.weights = np.random.rand(out_features, in_features).astype(np.float32)
        self.bias = np.random.rand(out_features).astype(np.float32)

        self.inputs = None
        self.has_weights = True

    def forward(self, inputs):
        self.inputs = inputs
        return np.dot(inputs, self.weights.T) + self.bias

    def backward(self, d_outputs):
        if self.inputs is None:
            raise NotImplementedError("Need to call forward function before backward function")

        d_weights = np.dot(d_outputs.T, self.inputs)
        d_bias = np.sum(d_outputs, axis=0)
        d_inputs = np.dot(d_outputs, self.weights)

        return {"d_weights": d_weights, "d_bias": d_bias, "d_out": d_inputs}

    def update(self, d_weights, d_bias, learning_rate):
        self.weights -= learning_rate * d_weights
        self.bias -= learning_rate * d_bias
