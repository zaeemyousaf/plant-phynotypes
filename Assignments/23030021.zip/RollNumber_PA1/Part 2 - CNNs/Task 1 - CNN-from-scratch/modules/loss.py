import numpy as np

class CrossEntropy:
    def __init__(self, eps=1e-8):
        self.eps = eps
        self.inputs = None
        self.targets = None

    def forward(self, inputs, targets):
        self.inputs = inputs
        self.targets = targets

        clipped_inputs = np.clip(inputs, self.eps, 1 - self.eps)
        loss = -np.sum(targets * np.log(clipped_inputs)) / inputs.shape[0]
        return loss

    def backward(self):
        batch_size = self.inputs.shape[0]
        d_inputs = -self.targets / np.clip(self.inputs, self.eps, 1 - self.eps)
        d_inputs = d_inputs / batch_size
        return {"d_out": d_inputs}
