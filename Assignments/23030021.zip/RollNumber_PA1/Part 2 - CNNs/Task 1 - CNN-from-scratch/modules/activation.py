import numpy as np

class ReLU:
    def __init__(self):
        self.inputs = None
        self.has_weights = False

    def forward(self, inputs):
        self.inputs = inputs
        return np.maximum(0, inputs)

    def backward(self, d_outputs):
        d_inputs = d_outputs * (self.inputs > 0)
        return {"d_out": d_inputs}


class Sigmoid:
    def __init__(self):
        self.inputs = None
        self.has_weights = False
        self.outputs = None

    def forward(self, inputs):
        self.inputs = inputs
        self.outputs = 1 / (1 + np.exp(-inputs))
        return self.outputs

    def backward(self, d_outputs):
        d_inputs = d_outputs * self.outputs * (1 - self.outputs)
        return {"d_out": d_inputs}


class Softmax:
    def __init__(self):
        self.inputs = None
        self.has_weights = False
        self.outputs = None

    def forward(self, inputs):
        self.inputs = inputs
        shifted_inputs = inputs - np.max(inputs, axis=-1, keepdims=True)
        exp_inputs = np.exp(shifted_inputs)
        self.outputs = exp_inputs / np.sum(exp_inputs, axis=-1, keepdims=True)
        return self.outputs

    def backward(self, d_outputs):
        d_inputs = np.empty_like(d_outputs)
        for i, (softmax_output, d_output) in enumerate(zip(self.outputs, d_outputs)):
            s = softmax_output.reshape(-1, 1)
            jacobian = np.diagflat(s) - np.dot(s, s.T)
            d_inputs[i] = np.dot(jacobian, d_output)
        return {"d_out": d_inputs}
