# Submission Instructions

1. **Naming Convention**: 
    - Your submission files should be named as `Rollnumber_PA2_1.ipynb` and `Rollnumber_PA2_1.py`.
    - For example, if your roll number is `25020240` then name the files `25020240_PA2_1.ipynb` and `25020240_PA2_1.py`.

2. **File Requirements**:
    - Submit both `.ipynb` and `.py` files for all parts.
    - Make sure all the cells are executed and the output is visible in the `.ipynb` file.

3. **Model Files**:
    - For parts 2 and 3, you need to submit the `.pth` files for each model.
    - Upload the model files to Google Drive or Dropbox (ONLY MODELS) and share the link.

4. **Marks Distribution**:
    - Part 1: 50 marks
    - Part 2: 75 marks
    - Part 3: 50 marks

5. **Restrictions**:
    - Use of Co-pilot, GPT, or any AI assistance is strictly prohibited.

6. **Assistance**:
    - Reach out to your TAs for any type of help.

7. **Deadline**:
    - The deadline for submission is `4th March 2025, 11:55 PM Pakistan Standard Time`.